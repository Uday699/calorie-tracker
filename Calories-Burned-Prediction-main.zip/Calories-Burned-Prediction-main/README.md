# Calories-Burned-Prediction
Calories-Burned-Prediction Using Machine Learning. (Regression Use case)

![image](https://user-images.githubusercontent.com/69152112/210569997-d595252d-ea28-4f3c-935d-3141407cf8c7.png)

### Implemented Machine Algorithms are:

##### 1. Linear Regression

##### 2. DecisionTree Regression

##### 3. RandomForest Regression

##### 4. XGBoost Regressor
